package com.myspring.covid;

import java.util.List;
import java.util.Map;

public interface CovidService {
	
	
	List<Map<String, Object>> list();

}
