package com.myspring.covid;

public class CovidVO {
	private String createDT;
	private String confCase;
	private String death;
	private String gubun;
	
	public String getCreateDT() {
		return createDT;
	}
	public void setCreateDT(String createDT) {
		this.createDT = createDT;
	}
	public String getConfCase() {
		return confCase;
	}
	public void setConfCase(String confCase) {
		this.confCase = confCase;
	}
	public String getDeath() {
		return death;
	}
	public void setDeath(String death) {
		this.death = death;
	}
	public String getGubun() {
		return gubun;
	}
	public void setGubun(String gubun) {
		this.gubun = gubun;
	}
	
}
