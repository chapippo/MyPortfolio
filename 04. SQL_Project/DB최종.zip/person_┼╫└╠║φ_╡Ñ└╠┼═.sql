insert into person(person_num,pt_code,doc_id,m_code,name,gen,age,phone,po_code)
        values(1,'001',2220110001,'01','�̿���','M',31,'010-1111-1111','101');
insert into person(person_num,pt_code,doc_id,m_code,name,gen,age,phone,po_code)
        values(2,'001',2220110002,'01','�輺��','M',28,'010-1111-1112','101');
insert into person(person_num,pt_code,doc_id,m_code,name,gen,age,phone,po_code)
        values(3,'001',2220510001,'05','����ȣ','F',35,'010-1111-1113','103');
insert into person(person_num,pt_code,doc_id,m_code,name,gen,age,phone,po_code)
        values(4,'001',2220510002,'05','����ȭ','M',48,'010-1111-1114','105');            
insert into person(person_num,pt_code,doc_id,m_code,name,gen,age,phone,po_code)
        values(5,'001',2221210001,'12','���¿�','F',31,'010-1111-1115','104');
insert into person(person_num,pt_code,doc_id,m_code,name,gen,age,phone,po_code)
        values(6,'001',2221210002,'12','�ȼ���','M',51,'010-1111-1116','106');
insert into person(person_num,pt_code,doc_id,m_code,name,gen,age,phone,po_code)
        values(7,'001',2221310001,'13','�輺��','M',37,'010-1111-1117','102');            
insert into person(person_num,pt_code,doc_id,m_code,name,gen,age,phone,po_code)
        values(8,'001',2221310002,'13','�̵���','M',31,'010-1111-1118','102');            
insert into person(person_num,pt_code,doc_id,m_code,name,gen,age,phone,po_code)
        values(9,'001',2224910001,'49','������','M',41,'010-1111-1119','104');
insert into person(person_num,pt_code,doc_id,m_code,name,gen,age,phone,po_code)
        values(10,'001',2224910002,'49','������','M',39,'010-1111-1121','103');
           
insert into person(person_num,pt_code,nur_id,m_code,name,gen,age,phone,po_code)
        values(11,'002',2220120001,'01','������','F',28,'010-2111-1111','201');
insert into person(person_num,pt_code,nur_id,m_code,name,gen,age,phone,po_code)
        values(12,'002',2220120002,'01','��ٹ�','F',33,'010-2112-1111','202');
insert into person(person_num,pt_code,nur_id,m_code,name,gen,age,phone,po_code)
        values(13,'002',2220520001,'05','�̺���','M',28,'010-2113-1111','201');
insert into person(person_num,pt_code,nur_id,m_code,name,gen,age,phone,po_code)
        values(14,'002',2220520002,'05','������','M',38,'010-2114-1111','204');
insert into person(person_num,pt_code,nur_id,m_code,name,gen,age,phone,po_code)
        values(15,'002',2221220001,'12','������','F',35,'010-2115-1111','203');
insert into person(person_num,pt_code,nur_id,m_code,name,gen,age,phone,po_code)
        values(16,'002',2221220002,'12','�տ���','F',31,'010-2116-1111','202');
insert into person(person_num,pt_code,nur_id,m_code,name,gen,age,phone,po_code)
        values(17,'002',2221320001,'13','���ν�','F',45,'010-2117-1111','201');
insert into person(person_num,pt_code,nur_id,m_code,name,gen,age,phone,po_code)
        values(18,'002',2221320002,'13','���ҿ�','F',35,'010-2118-1111','201');
insert into person(person_num,pt_code,nur_id,m_code,name,gen,age,phone,po_code)
        values(29,'002',2224920001,'49','������','F',27,'010-2119-1111','201');
insert into person(person_num,pt_code,nur_id,m_code,name,gen,age,phone,po_code)
        values(20,'002',2224920002,'49','�ǳ���','F',27,'010-2121-1111','201');
         
insert into person(person_num,pt_code,pat_id,name,gen,age,phone)
        values(21,'003',1,'������','M',34,'010-3111-1111');
insert into person(person_num,pt_code,pat_id,name,gen,age,phone)
        values(22,'003',2,'�ֽ���','M',34,'010-3112-1111');
insert into person(person_num,pt_code,pat_id,name,gen,age,phone)
        values(23,'003',3,'������','F',30,'010-3113-1111');            
insert into person(person_num,pt_code,pat_id,name,gen,age,phone)
        values(24,'003',4,'�ְ�â��','M',35,'010-3114-1111');
insert into person(person_num,pt_code,pat_id,name,gen,age,phone)
        values(25,'003',5,'�����','F',20,'010-3115-1111');